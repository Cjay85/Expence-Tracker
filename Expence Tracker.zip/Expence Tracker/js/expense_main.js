const transactions = JSON.parse(localStorage.getItem("transactions")) || [];

const formatted = new Intl.NumberFormat('en-US', {
    style: 'currency',
    currency: 'IRR',
    signDisplay: "always",
})


const list = document.getElementById('transactionList');
const status = document.getElementById('status');
const form = document.getElementById('transactionForm');
const balance = document.getElementById("balance");
const income = document.getElementById("income");
const expense = document.getElementById("expense");
const searchInput = document.getElementById('searchCategory');


// update Total

function updateTotal() {
    const incomeTotal = transactions
        .filter(item => item.type === 'income')
        .reduce((total, item) => total + item.amount, 0);

    const expenseTotal = transactions
        .filter(item => item.type === 'expense')
        .reduce((total, item) => total + item.amount, 0);

    const balanceTotal = incomeTotal - expenseTotal;

    balance.textContent = formatted.format(balanceTotal);
    income.textContent = formatted.format(incomeTotal);
    expense.textContent = formatted.format(expenseTotal * -1);
}

// search categories
searchInput.addEventListener('input', function () {
    const keyword = this.value.toLowerCase();
    const filtered = transactions.filter(item =>
        item.categories.toLowerCase().includes(keyword)
    );
    renderList(filtered);
});

// render List 
function renderList(listData = transactions) {
    list.innerHTML = "";

    status.textContent = ""
    if (listData.length === 0) {
        status.textContent = "No transiction found!";
        return;
    }

    listData.forEach(({ id, name, date, amount, type, categories }) => {
        const sign = 'income' === type ? 1 : -1;

        const li = document.createElement("li");
        li.innerHTML = `
        <div class="name">
        <h4>${name}</h4>
        <p>${new Date(date).toLocaleDateString()}</p>
        <span class="categorie">${categories}</span>
        </div>
        <div class="amount ${type}">
        <span>${formatted.format(amount * sign)}</span>
        </div>
        
        <div class="action">
        <svg xmlns="http://www.w3.org/2000/svg" width="30" height="30" onclick="deleteTransaction(${id})"><!-- Icon from Grommet Icons by Grommet - https://www.apache.org/licenses/LICENSE-2.0 -->
        
        <path fill="none" stroke="currentColor" stroke-width="2" d="M12 22c5.523 0 10-4.477 10-10S17.523 2 12 2S2 6.477 2 12s4.477 10 10 10ZM6 12h12"/></svg>
        </div>
        `
        list.appendChild(li);
    })

}

renderList();
updateTotal();

// delete Item
function deleteTransaction(id) {
    const confirmed = confirm('Do you Sure Delete Item?');
    if (confirmed) {
        const index = transactions.findIndex((find_index) => find_index.id === id);
        transactions.splice(index, 1);
    } else {
        alert('No Deleted');
        this.stopPropagation();
        return;
    }
    renderList();
    saveTransactions();
    updateTotal();
}


// form Transaction
form.addEventListener('submit', addTransaction);

function addTransaction(e) {
    e.preventDefault();

    const formData = new FormData(e.target);

    transactions.push({
        id: transactions.length + 1,
        name: formData.get('name'),
        amount: parseFloat(formData.get('amount')),
        date: new Date(formData.get('date')),
        categories: formData.get('categories'),
        type: "on" === formData.get("type") ? "expense" : "income"
    });
    this.reset();

    renderList();
    saveTransactions();
    updateTotal();
}

document.querySelector('.option').addEventListener('click', () => {
    const input = document.getElementById('type');
    input.checked = !input.checked;
});

function saveTransactions() {
    transactions.sort((a, b) => new Date(b.date) - new Date(a.date));

    localStorage.setItem("transactions", JSON.stringify(transactions));
}